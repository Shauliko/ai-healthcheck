// Env var presence + min length. NEVER logs the value.
import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

// Lazily load .env if present, so users don't have to source it manually.
let envCache = null;
function loadEnvFiles(cwd) {
  if (envCache) return envCache;
  const merged = { ...process.env };
  for (const name of ['.env.local', '.env']) {
    const p = join(cwd || process.cwd(), name);
    if (existsSync(p)) {
      try {
        const text = readFileSync(p, 'utf8');
        for (const line of text.split('\n')) {
          const t = line.trim();
          if (!t || t.startsWith('#')) continue;
          const eq = t.indexOf('=');
          if (eq < 0) continue;
          const k = t.slice(0, eq).trim();
          let v = t.slice(eq + 1).trim();
          if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
            v = v.slice(1, -1);
          }
          if (!(k in merged)) merged[k] = v;
        }
      } catch {}
    }
  }
  envCache = merged;
  return envCache;
}

export default {
  async run(check) {
    if (!check.var) return { status: 'fail', detail: 'env_present check missing "var"', hint: 'Add var: MY_ENV_VAR' };
    const env = loadEnvFiles(process.cwd());
    const value = env[check.var];
    const minLength = check.min_length ?? 1;

    if (value === undefined || value === '') {
      return {
        status: 'fail',
        detail: `${check.var} is not set`,
        hint: `Add ${check.var}=... to your .env or hosting env vars.`,
        meta: { var: check.var, set: false },
      };
    }
    if (value.length < minLength) {
      return {
        status: 'fail',
        detail: `${check.var} too short (${value.length} chars, expected >= ${minLength})`,
        hint: 'Likely a placeholder value (e.g., "your-key-here").',
        meta: { var: check.var, length: value.length, min_length: minLength },
      };
    }
    return { status: 'ok', detail: `set (length=${value.length})`, meta: { var: check.var, length: value.length } };
  },
};
