// Generic webhook signing secret presence + optional prefix check.
import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

function loadEnv(cwd) {
  const merged = { ...process.env };
  for (const name of ['.env.local', '.env']) {
    const p = join(cwd || process.cwd(), name);
    if (existsSync(p)) {
      try {
        const text = readFileSync(p, 'utf8');
        for (const line of text.split('\n')) {
          const t = line.trim();
          if (!t || t.startsWith('#')) continue;
          const eq = t.indexOf('=');
          if (eq < 0) continue;
          const k = t.slice(0, eq).trim();
          let v = t.slice(eq + 1).trim();
          if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
          if (!(k in merged)) merged[k] = v;
        }
      } catch {}
    }
  }
  return merged;
}

export default {
  async run(check) {
    if (!check.var) return { status: 'fail', detail: 'webhook_secret check missing "var"', hint: 'Add var: STRIPE_WEBHOOK_SECRET' };
    const env = loadEnv(process.cwd());
    const v = env[check.var];
    const minLength = check.min_length ?? 20;

    if (!v) {
      return {
        status: 'fail',
        detail: `${check.var} is not set`,
        hint: 'Webhooks will fail signature verification — set this in your env.',
      };
    }
    if (check.expect_prefix && !v.startsWith(check.expect_prefix)) {
      return {
        status: 'fail',
        detail: `${check.var} does not start with "${check.expect_prefix}"`,
        hint: `Wrong kind of secret? Stripe uses whsec_, GitHub uses arbitrary, etc.`,
        meta: { var: check.var, length: v.length, expected_prefix: check.expect_prefix },
      };
    }
    if (v.length < minLength) {
      return {
        status: 'fail',
        detail: `${check.var} too short (${v.length}, expected >= ${minLength})`,
        hint: 'Probably a placeholder.',
      };
    }
    return { status: 'ok', detail: `set (length=${v.length})` };
  },
};
